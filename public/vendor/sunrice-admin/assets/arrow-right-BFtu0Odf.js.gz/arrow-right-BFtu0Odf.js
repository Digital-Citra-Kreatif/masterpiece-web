import{c as a}from"./i18n-CJojkL_p.js";const o={name:"arrow-right",size:24,node:[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]};o.node;const t=a(o);export{t as A};
