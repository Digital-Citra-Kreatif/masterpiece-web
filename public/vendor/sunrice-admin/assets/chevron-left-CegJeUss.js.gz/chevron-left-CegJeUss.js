import{c as o}from"./i18n-C4NKvdLL.js";const e={name:"chevron-left",size:24,node:[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]};e.node;const t=o(e);export{t as C};
