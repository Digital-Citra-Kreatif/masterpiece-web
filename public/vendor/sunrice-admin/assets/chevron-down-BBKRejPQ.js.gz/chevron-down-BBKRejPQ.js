import{c as n}from"./i18n-CJojkL_p.js";const o={name:"chevron-down",size:24,node:[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]};o.node;const c=n(o);export{c as C};
