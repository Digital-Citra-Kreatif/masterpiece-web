import { c } from "./createLucideIcon-Ccbp7F45.js";
const e = {
  name: "search",
  size: 24,
  node: [
    ["path", { d: "m21 21-4.34-4.34", key: "14j7rj" }],
    ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }]
  ]
};
e.node;
const o = c(e);
export {
  o as S
};
