import { c as o } from "./createLucideIcon-Ccbp7F45.js";
const e = {
  name: "chevron-right",
  size: 24,
  node: [["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]]
};
e.node;
const n = o(e);
export {
  n as C
};
